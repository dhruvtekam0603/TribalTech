import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { WhyUs } from './components/WhyUs';
import { Process } from './components/Process';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-brand-soft text-brand-navy antialiased">
      {/* 1. Navbar */}
      <Navbar />

      <main className="flex-grow">
        {/* 2. Hero */}
        <Hero />

        {/* 3. Services */}
        <Services />

        {/* 4. Featured Work / Portfolio */}
        <Portfolio />

        {/* 5. Why TribalTech */}
        <WhyUs />

        {/* 6. Our Process */}
        <Process />

        {/* 7. Contact / CTA */}
        <Contact />
      </main>

      {/* 8. Footer */}
      <Footer />

      {/* Floating WhatsApp Quick Action */}
      <FloatingWhatsApp />
    </div>
  );
};

export default App;
