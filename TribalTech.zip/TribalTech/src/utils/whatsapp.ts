import { WHATSAPP_NUMBER } from '../config/site';
import { ContactFormData } from '../types';

/**
 * Clean phone number to digits only for wa.me format
 */
export function formatPhoneNumber(phone: string): string {
  return phone.replace(/[^0-9]/g, '');
}

/**
 * Builds a direct WhatsApp chat URL with an optional prefilled message
 */
export function getWhatsAppUrl(message?: string): string {
  const cleanNumber = formatPhoneNumber(WHATSAPP_NUMBER);
  if (!message) {
    return `https://wa.me/${cleanNumber}`;
  }
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * Pre-formatted message for General Inquiries
 */
export function getGeneralInquiryUrl(): string {
  const message = `Hello TribalTech! 👋 I visited your website and would like to discuss a digital project for my business.`;
  return getWhatsAppUrl(message);
}

/**
 * Pre-formatted message for Specific Project / Concept Exploration
 */
export function getProjectInquiryUrl(projectName: string): string {
  const message = `Hi TribalTech! I saw your "${projectName}" concept on the website and would love to build something similar for our business.`;
  return getWhatsAppUrl(message);
}

/**
 * Pre-formatted message for Specific Service
 */
export function getServiceInquiryUrl(serviceTitle: string): string {
  const message = `Hi TribalTech team! I am interested in your "${serviceTitle}" service. Could you tell me more about the process and deliverables?`;
  return getWhatsAppUrl(message);
}

/**
 * Formats user form input into an organized WhatsApp message
 */
export function getContactFormWhatsAppUrl(formData: ContactFormData): string {
  const lines = [
    `*New Project Inquiry via TribalTech Website*`,
    `----------------------------------------`,
    `👤 *Name:* ${formData.name}`,
    formData.businessName ? `🏢 *Business:* ${formData.businessName}` : null,
    `📞 *Contact:* ${formData.contact}`,
    `🛠 *Service Required:* ${formData.serviceNeeded}`,
    `📝 *Project Overview:*`,
    formData.message,
    `----------------------------------------`,
    `_Sent from tribaltech.dev_`,
  ].filter(Boolean);

  return getWhatsAppUrl(lines.join('\n'));
}
