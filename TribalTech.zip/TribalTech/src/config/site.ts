import { NavItem, ServiceItem, ProjectConcept, WhyUsFeature, ProcessStep } from '../types';

/**
 * PRIMARY CONTACT CONFIGURATION
 * Note: Replace this placeholder phone number with the official TribalTech WhatsApp number.
 * Format: Country code without '+' followed by phone digits (e.g., '919876543210' for India).
 */
export const WHATSAPP_NUMBER = "917247670652";

export const SITE_CONFIG = {
  name: "TribalTech",
  nameHindi: "Tribalटेक",
  tagline: "Digital Solutions for Ambitious Businesses",
  headlineAccent: "more than just a presence.",
  heroDescription: "We build modern websites and digital solutions that help businesses grow, connect with customers, and work smarter.",
  supportingTrust: "Built for businesses that are ready to grow.",
  email: "contact@tribaltech.dev",
  instagram: "https://instagram.com/tribaltech",
  teamSize: "3-member core studio",
  location: "India",
  foundingYear: 2024,
};

export const NAV_ITEMS: NavItem[] = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "Our Work", href: "#work" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export const SERVICES: ServiceItem[] = [
  {
    id: "business-websites",
    number: "01",
    title: "Business Websites",
    description: "Modern, responsive websites that establish your brand, showcase your business, and help customers find you online.",
    tags: ["High Performance", "Mobile First", "SEO Ready"],
    features: ["Custom UI/UX Design", "Brand Identity Integration", "Speed & Core Web Vitals", "Direct Lead Inquiries"],
    icon: "Globe",
  },
  {
    id: "ecommerce-solutions",
    number: "02",
    title: "E-commerce Solutions",
    description: "Online stores designed to showcase products, simplify shopping, and help businesses sell online.",
    tags: ["Product Catalogs", "Checkout Flows", "WhatsApp Orders"],
    features: ["Seamless Cart Experience", "Inventory Showcase", "Payment Gateway Setup", "Order Notifications"],
    icon: "ShoppingBag",
  },
  {
    id: "website-redesign",
    number: "03",
    title: "Website Redesign",
    description: "Transform outdated websites into modern, fast, responsive, and visually engaging experiences.",
    tags: ["Design Modernization", "UX Audit", "Mobile Optimization"],
    features: ["Visual Hierarchy Overhaul", "Codebase Modernization", "Mobile Responsiveness", "Higher Conversion"],
    icon: "RefreshCw",
  },
  {
    id: "custom-web-applications",
    number: "04",
    title: "Custom Web Applications",
    description: "Purpose-built digital tools that solve specific business problems and improve everyday workflows.",
    tags: ["Client Portals", "Custom Dashboards", "Calculators"],
    features: ["Role-based Access", "Real-time Data", "Tailored Business Logic", "Secure Architecture"],
    icon: "Layers",
  },
  {
    id: "business-automation",
    number: "05",
    title: "Business Automation",
    description: "Simplify repetitive processes, reduce manual work, and make your business workflows more efficient.",
    tags: ["WhatsApp Bots", "CRM Sync", "Notification Flows"],
    features: ["Automated Inquiries", "Form-to-Chat Pipelines", "Data Collection", "Error-free Operations"],
    icon: "Cpu",
  },
  {
    id: "digital-experiences",
    number: "06",
    title: "Digital Experiences",
    description: "Customized digital solutions, interactive experiences, and technology tailored to your business needs.",
    tags: ["Interactive UI", "AI Integrations", "Custom Tools"],
    features: ["Interactive Walkthroughs", "Smart Search & AI", "Custom Calculations", "Engaging Micro-interactions"],
    icon: "Sparkles",
  },
];

export const PROJECTS: ProjectConcept[] = [
  {
    id: "restaurant-cafe",
    title: "The Copper Kettle Cafe & Bistro",
    category: "Website Design · Hospitality",
    tagline: "Warm, artisan culinary atmosphere with instant WhatsApp order & table reservation.",
    description: "A modern restaurant website concept featuring an interactive curated menu, venue ambiance showcase, opening hours, Google Maps location, and frictionless WhatsApp-based customer inquiries.",
    industry: "Hospitality",
    color: {
      primary: "#7C2D12",
      accent: "#EA580C",
      badgeBg: "#FFEDD5",
      badgeText: "#9A3412",
    },
    highlights: [
      "Digital Menu with Category Filtering",
      "Direct Table Reservation via WhatsApp",
      "Event & Private Dining Booking",
      "Instant Location & Operating Status",
    ],
    features: [
      "Mobile-optimized quick menu with dietary tags (Vegetarian, Vegan, Chef's Special)",
      "One-click WhatsApp inquiry with table size and timing",
      "Atmospheric photography layout with warm culinary aesthetics",
      "Interactive opening hours badge showing real-time Open/Closed status",
    ],
    techStack: ["React", "Tailwind CSS", "WhatsApp Business API Hook", "Vite"],
    mockup: {
      headerTitle: "The Copper Kettle",
      heroHeadline: "Artisan Coffee, Sourdough Bakes & Seasonal Cuisine.",
      heroSubtitle: "Handcrafted flavours in the heart of the city. Open everyday from 8:00 AM.",
      ctaText: "Reserve a Table",
      cardItems: [
        { title: "Specialty Truffle Sourdough", desc: "Wild mushroom, shaved black truffle, aged gruyère.", price: "₹480", tag: "Chef's Pick" },
        { title: "Single Origin Cold Brew", desc: "Steeped for 18 hours with hints of caramel and hazelnut.", price: "₹240", tag: "Beverage" },
        { title: "Burrata & Heirloom Salad", desc: "Fresh burrata, balsamic reduction, basil oil.", price: "₹420", tag: "Fresh" },
      ],
    },
  },
  {
    id: "retail-fashion",
    title: "AURA Minimal Goods & Apparel",
    category: "E-commerce · Retail",
    tagline: "Editorial minimalist digital storefront crafted for high-aesthetic lifestyle brands.",
    description: "An online storefront concept designed to showcase products, curated seasonal collections, lookbooks, promotions, and a streamlined shopping experience with fast cart flows.",
    industry: "Retail & E-commerce",
    color: {
      primary: "#0F172A",
      accent: "#2563EB",
      badgeBg: "#E0E7FF",
      badgeText: "#3730A3",
    },
    highlights: [
      "Curated Seasonal Lookbook Layout",
      "Product Variant Selector (Size/Color)",
      "Instant Inquiry & Checkout Routing",
      "Promotional Campaign Banners",
    ],
    features: [
      "Editorial product grid with clean whitespace and typographic hierarchy",
      "Smooth quick-view modal with high-res product angles and specs",
      "Cart drawer with live order subtotal and shipping calculator",
      "Optimized for 60fps scrolling and instant image loading on mobile devices",
    ],
    techStack: ["Next-gen React", "Tailwind CSS", "Headless Cart", "Responsive Grid"],
    mockup: {
      headerTitle: "AURA / Studio",
      heroHeadline: "Timeless Essentials. Mindfully Designed.",
      heroSubtitle: "Edition 04 — Modern silhouettes built from organic heavyweight textiles.",
      ctaText: "Shop the Collection",
      cardItems: [
        { title: "Oversized Merino Pullover", desc: "100% fine merino wool in natural charcoal.", price: "₹3,400", tag: "Edition 04" },
        { title: "Architectural Canvas Tote", desc: "Water-resistant 18oz duck canvas with leather accents.", price: "₹1,850", tag: "Bestseller" },
        { title: "Tailored Relaxed Trouser", desc: "Japanese cotton twill with elasticated interior waist.", price: "₹2,900", tag: "New" },
      ],
    },
  },
  {
    id: "real-estate",
    title: "Apex Horizon Realty",
    category: "Web Design · Property",
    tagline: "Premium residential & commercial property portal with immersive listing tours.",
    description: "A real estate website concept featuring premium property listings, interactive filter criteria, comprehensive floor plans, brochure downloads, and direct broker consultation forms.",
    industry: "Real Estate",
    color: {
      primary: "#0B132B",
      accent: "#0D9488",
      badgeBg: "#CCFBF1",
      badgeText: "#115E59",
    },
    highlights: [
      "Dynamic Property Search & Filtering",
      "High-Resolution Gallery & Floor Plans",
      "Schedule Private Site Visit Form",
      "Mortgage & ROI Estimation Widget",
    ],
    features: [
      "Multi-facet search: location, budget range, BHK type, possession status",
      "Detailed property profile pages with neighborhood highlights and connectivity",
      "Instant WhatsApp consultation button pre-filled with property listing ID",
      "Lead capture optimized for high-value buyer conversion",
    ],
    techStack: ["React", "TypeScript", "Tailwind CSS", "Interactive Filter Hooks"],
    mockup: {
      headerTitle: "APEX HORIZON",
      heroHeadline: "Signature Residences In Prime Urban Enclaves.",
      heroSubtitle: "Curated luxury apartments, penthouses, and gated villa communities.",
      ctaText: "Explore Properties",
      cardItems: [
        { title: "The Meridian Penthouse", desc: "4 BHK · 4,200 sq.ft · Private Rooftop Deck", price: "₹4.85 Cr", tag: "Ready to Move" },
        { title: "Verdant Groves Villa 18", desc: "5 BHK · 5,600 sq.ft · Lake View Garden", price: "₹6.20 Cr", tag: "Exclusive" },
        { title: "Skyline Tower Residence", desc: "3 BHK · 2,150 sq.ft · Panoramic City Skyline", price: "₹2.40 Cr", tag: "New Launch" },
      ],
    },
  },
];

export const WHY_US_FEATURES: WhyUsFeature[] = [
  {
    title: "Built Around You",
    description: "We take the time to understand your unique business requirements, target customers, and operational bottlenecks before writing a line of code. Your business is not a cookie-cutter template.",
    metric: "100%",
    metricLabel: "Custom Tailored",
    icon: "UserCheck",
  },
  {
    title: "Modern by Design",
    description: "Clean interfaces, thoughtful user experiences, fast loading times, and resilient engineering built for modern consumers who demand instant, effortless mobile experiences.",
    metric: "< 1.5s",
    metricLabel: "Lightning Performance",
    icon: "Sparkles",
  },
  {
    title: "Practical Solutions",
    description: "We focus on features that solve real problems, generate leads, and streamline your operations—avoiding bloated code, unnecessary widgets, or complexity for complexity's sake.",
    metric: "0",
    metricLabel: "Gimmicks or Bloat",
    icon: "Target",
  },
  {
    title: "Direct Communication",
    description: "You work directly with our compact core team of 3 developers and designers. No account managers, no ticket delays, and no communication telephone game.",
    metric: "Direct",
    metricLabel: "Studio Collaboration",
    icon: "MessageSquare",
  },
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    step: "01",
    title: "Discover",
    description: "We learn about your business, target audience, competition, existing challenges, and project goals to formulate a pragmatic roadmap.",
    deliverables: ["Requirement audit", "Scope definition", "Architecture blueprint"],
  },
  {
    step: "02",
    title: "Design",
    description: "We craft clean, responsive UI wireframes and visual designs tailored to your brand identity, with emphasis on clarity and conversion.",
    deliverables: ["Visual layout", "Component styling", "Mobile-first mockups"],
  },
  {
    step: "03",
    title: "Build",
    description: "We engineer your website or web tool using modern standards, fast tech stacks, clean code, and AI-assisted precision development.",
    deliverables: ["Responsive frontend", "Custom logic & tools", "Performance optimization"],
  },
  {
    step: "04",
    title: "Launch",
    description: "We deploy your project to production, verify search engine tags and mobile responsiveness, and support your smooth handover.",
    deliverables: ["Domain setup", "SEO metadata verification", "Post-launch support"],
  },
];
