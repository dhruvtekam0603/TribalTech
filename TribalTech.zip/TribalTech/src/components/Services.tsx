import React from 'react';
import { SERVICES } from '../config/site';
import { getServiceInquiryUrl } from '../utils/whatsapp';
import {
  Globe,
  ShoppingBag,
  RefreshCw,
  Layers,
  Cpu,
  Sparkles,
  ArrowRight,
  Check,
} from 'lucide-react';

export const Services: React.FC = () => {
  // Map icon strings to Lucide components
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Globe':
        return <Globe className="w-5 h-5" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-5 h-5" />;
      case 'RefreshCw':
        return <RefreshCw className="w-5 h-5" />;
      case 'Layers':
        return <Layers className="w-5 h-5" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5" />;
      default:
        return <Globe className="w-5 h-5" />;
    }
  };

  return (
    <section id="services" className="py-20 md:py-28 bg-white border-y border-brand-border/60 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-brand-slate text-xs font-bold tracking-widest uppercase">
            <span>WHAT WE DO</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-brand-navy tracking-tight">
            Digital solutions built around your business.
          </h2>

          <p className="text-base sm:text-lg text-brand-slate leading-relaxed">
            Every business is different. We create practical digital experiences designed around your goals, your customers, and the way you work.
          </p>
        </div>

        {/* 6 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="group relative bg-brand-soft hover:bg-white rounded-2xl p-7 border border-brand-border/80 hover:border-brand-blue/40 shadow-soft-sm hover:shadow-soft-lg transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Card Top: Number & Subtle Icon */}
                <div className="flex items-center justify-between mb-6">
                  <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-md bg-white border border-slate-200 text-brand-slate group-hover:border-brand-blue/30 group-hover:text-brand-blue transition-colors">
                    {service.number}
                  </span>
                  
                  <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-brand-navy group-hover:bg-brand-blue group-hover:text-white group-hover:border-brand-blue transition-all duration-300">
                    {getIcon(service.icon)}
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-brand-navy mb-3 group-hover:text-brand-blue transition-colors">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-sm text-brand-slate leading-relaxed mb-6 font-normal">
                  {service.description}
                </p>

                {/* Features list */}
                <ul className="space-y-2 mb-6 border-t border-slate-200/60 pt-4">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-xs text-brand-slate-dark">
                      <Check className="w-3.5 h-3.5 text-brand-blue flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Card Footer: Quick WhatsApp inquiry action */}
              <div className="pt-4 border-t border-slate-200/60 flex items-center justify-between">
                <div className="flex flex-wrap gap-1.5">
                  {service.tags.slice(0, 2).map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-200/60 text-slate-700"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <a
                  href={getServiceInquiryUrl(service.title)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-brand-navy group-hover:text-brand-blue transition-colors"
                  aria-label={`Inquire about ${service.title}`}
                >
                  <span>Inquire</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner Note */}
        <div className="mt-14 p-6 rounded-2xl bg-slate-100/80 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <h4 className="text-base font-bold text-brand-navy">
              Need something specific or custom?
            </h4>
            <p className="text-sm text-brand-slate">
              We specialize in custom business logic, workflows, and tailored web applications.
            </p>
          </div>
          <a
            href={getServiceInquiryUrl("Custom Requirements")}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 px-5 py-2.5 rounded-full text-xs font-semibold bg-brand-navy text-white hover:bg-brand-blue transition-colors flex items-center gap-2"
          >
            <span>Discuss Custom Build</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>

      </div>
    </section>
  );
};
