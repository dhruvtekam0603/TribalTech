import React, { useState, useEffect } from 'react';
import { getGeneralInquiryUrl } from '../utils/whatsapp';
import { MessageCircle, X } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show floating button after scrolling down 300px
      if (window.scrollY > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3">
      {/* Tooltip message */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 bg-brand-navy text-white text-xs px-3.5 py-2 rounded-xl shadow-soft-lg border border-slate-700 animate-in fade-in slide-in-from-right duration-200">
          <span>Need a quick quote? Chat with us!</span>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-slate-400 hover:text-white"
            aria-label="Dismiss tooltip"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={getGeneralInquiryUrl()}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        className="group relative flex items-center justify-center w-13 h-13 p-3.5 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-soft-xl hover:shadow-glow-blue transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-2"
        aria-label="Chat with TribalTech on WhatsApp"
        title="Chat with TribalTech on WhatsApp"
      >
        {/* Subtle Pulse Rings */}
        <span className="absolute -inset-1 rounded-full bg-emerald-400 opacity-30 group-hover:animate-ping pointer-events-none" />
        
        <MessageCircle className="w-6 h-6 relative z-10" />

        {/* Small active badge */}
        <span className="absolute top-0 right-0 w-3 h-3 bg-white rounded-full border-2 border-emerald-500 flex items-center justify-center">
          <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full" />
        </span>
      </a>
    </div>
  );
};
