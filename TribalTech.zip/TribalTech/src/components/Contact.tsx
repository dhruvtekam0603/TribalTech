import React, { useState } from 'react';
import { ContactFormData } from '../types';
import { getContactFormWhatsAppUrl, getGeneralInquiryUrl } from '../utils/whatsapp';
import {
  MessageCircle,
  Send,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  ArrowRight,
} from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    businessName: '',
    contact: '',
    serviceNeeded: 'Business Website',
    message: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof ContactFormData, string>>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof ContactFormData, string>> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Please provide your name';
    }
    if (!formData.contact.trim()) {
      newErrors.contact = 'Please provide an email or phone number';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Please provide a brief project overview';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Build the formatted WhatsApp link
    const waUrl = getContactFormWhatsAppUrl(formData);
    
    // Set submission state and open WhatsApp
    setIsSubmitted(true);
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  const handleCopySummary = () => {
    const summary = `Name: ${formData.name}\nBusiness: ${formData.businessName || 'N/A'}\nContact: ${formData.contact}\nService: ${formData.serviceNeeded}\nMessage: ${formData.message}`;
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      businessName: '',
      contact: '',
      serviceNeeded: 'Business Website',
      message: '',
    });
    setErrors({});
    setIsSubmitted(false);
  };

  return (
    <section id="contact" className="py-20 md:py-28 bg-brand-navy text-white relative overflow-hidden">
      {/* Background ambient accents */}
      <div className="absolute inset-0 bg-grid-pattern-dark opacity-30 pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-brand-blue/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Heading & Quick CTA */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-900/40 border border-blue-500/30 text-blue-300 text-xs font-bold tracking-widest uppercase">
              <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
              <span>LET'S CONNECT</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
              Have an idea? Let's build something meaningful.
            </h2>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
              Whether you need a website, want to modernize your business, or have an idea for a digital tool, let's talk about it.
            </p>

            {/* Direct Quick WhatsApp Action Button */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <a
                href={getGeneralInquiryUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 text-white shadow-soft transition-all duration-200"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Us Directly</span>
              </a>

              <a
                href="#contact-form"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('name')?.focus();
                }}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full text-sm font-semibold bg-white/10 hover:bg-white/20 border border-white/15 text-white transition-colors"
              >
                <span>Fill Project Form</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>

            {/* Studio Availability Status Card */}
            <div className="p-5 rounded-2xl bg-brand-navy-surface border border-slate-700/60 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium">Studio Capacity</span>
                <span className="inline-flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  Accepting Q1 Projects
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Direct turnaround with our 3-person core team. Typically responding within 2–4 hours on WhatsApp during business days.
              </p>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-brand-navy-surface/90 border border-slate-700/70 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-sm">
              
              {isSubmitted ? (
                /* Success & Next Step State */
                <div className="text-center py-8 space-y-6 animate-in fade-in duration-300">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold text-white">
                      Inquiry Formatted For WhatsApp!
                    </h3>
                    <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                      Your inquiry has been compiled. If WhatsApp did not open automatically in your browser, click the button below to send your pre-filled message.
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                    <a
                      href={getContactFormWhatsAppUrl(formData)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 text-white transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Open WhatsApp Now</span>
                    </a>

                    <button
                      onClick={handleCopySummary}
                      type="button"
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full text-sm font-semibold bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-colors"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      <span>{copied ? 'Copied to Clipboard' : 'Copy Inquiry Summary'}</span>
                    </button>
                  </div>

                  <div className="pt-4 border-t border-slate-700/60">
                    <button
                      onClick={handleReset}
                      type="button"
                      className="text-xs text-slate-400 hover:text-white underline underline-offset-4"
                    >
                      ← Submit another inquiry
                    </button>
                  </div>
                </div>
              ) : (
                /* Interactive Form */
                <form id="contact-form" onSubmit={handleSubmit} className="space-y-5">
                  <div className="space-y-1">
                    <h3 className="text-xl sm:text-2xl font-bold text-white">
                      Tell us about your project
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-400">
                      No commitment required. We'll review your goals and suggest practical next steps.
                    </p>
                  </div>

                  {/* Name Field */}
                  <div className="space-y-1.5">
                    <label htmlFor="name" className="block text-xs font-semibold text-slate-300">
                      Your Name <span className="text-rose-400">*</span>
                    </label>
                    <input
                      id="name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => {
                        setFormData({ ...formData, name: e.target.value });
                        if (errors.name) setErrors({ ...errors, name: undefined });
                      }}
                      placeholder="e.g. Rahul Sharma"
                      className={`w-full px-4 py-3 rounded-xl bg-brand-navy-deep/80 border text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue transition-colors ${
                        errors.name ? 'border-rose-500' : 'border-slate-700'
                      }`}
                    />
                    {errors.name && (
                      <p className="text-xs text-rose-400 flex items-center gap-1 mt-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{errors.name}</span>
                      </p>
                    )}
                  </div>

                  {/* Business Name Field (Optional) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label htmlFor="businessName" className="block text-xs font-semibold text-slate-300">
                        Business Name
                      </label>
                      <span className="text-[11px] text-slate-500">Optional</span>
                    </div>
                    <input
                      id="businessName"
                      type="text"
                      value={formData.businessName}
                      onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                      placeholder="e.g. Copper Kettle Cafe, Apex Properties"
                      className="w-full px-4 py-3 rounded-xl bg-brand-navy-deep/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue transition-colors"
                    />
                  </div>

                  {/* Email or Phone */}
                  <div className="space-y-1.5">
                    <label htmlFor="contact" className="block text-xs font-semibold text-slate-300">
                      Email or Phone Number <span className="text-rose-400">*</span>
                    </label>
                    <input
                      id="contact"
                      type="text"
                      value={formData.contact}
                      onChange={(e) => {
                        setFormData({ ...formData, contact: e.target.value });
                        if (errors.contact) setErrors({ ...errors, contact: undefined });
                      }}
                      placeholder="e.g. rahul@business.com or +91 98765 43210"
                      className={`w-full px-4 py-3 rounded-xl bg-brand-navy-deep/80 border text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue transition-colors ${
                        errors.contact ? 'border-rose-500' : 'border-slate-700'
                      }`}
                    />
                    {errors.contact && (
                      <p className="text-xs text-rose-400 flex items-center gap-1 mt-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{errors.contact}</span>
                      </p>
                    )}
                  </div>

                  {/* What do you need? Select Dropdown */}
                  <div className="space-y-1.5">
                    <label htmlFor="serviceNeeded" className="block text-xs font-semibold text-slate-300">
                      What do you need?
                    </label>
                    <select
                      id="serviceNeeded"
                      value={formData.serviceNeeded}
                      onChange={(e) => setFormData({ ...formData, serviceNeeded: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-brand-navy-deep/80 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue transition-colors"
                    >
                      <option value="Business Website">Business Website (Company & Portfolio)</option>
                      <option value="Restaurant or Cafe Website">Restaurant, Cafe & Food Menu Website</option>
                      <option value="E-commerce Store">E-commerce Store & Online Shop</option>
                      <option value="Website Redesign">Website Redesign & Modernization</option>
                      <option value="Custom Web Application">Custom Web Application / Internal Tool</option>
                      <option value="Workflow & Business Automation">Workflow & Business Automation</option>
                      <option value="Other / Custom Inquiry">Other / Custom Inquiry</option>
                    </select>
                  </div>

                  {/* Project Description */}
                  <div className="space-y-1.5">
                    <label htmlFor="message" className="block text-xs font-semibold text-slate-300">
                      Brief Description of Project <span className="text-rose-400">*</span>
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      value={formData.message}
                      onChange={(e) => {
                        setFormData({ ...formData, message: e.target.value });
                        if (errors.message) setErrors({ ...errors, message: undefined });
                      }}
                      placeholder="Tell us about your business, current website (if any), and what you want to achieve..."
                      className={`w-full px-4 py-3 rounded-xl bg-brand-navy-deep/80 border text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue transition-colors ${
                        errors.message ? 'border-rose-500' : 'border-slate-700'
                      }`}
                    />
                    {errors.message && (
                      <p className="text-xs text-rose-400 flex items-center gap-1 mt-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{errors.message}</span>
                      </p>
                    )}
                  </div>

                  {/* Form Submission Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-4 px-6 rounded-xl font-bold text-sm bg-brand-blue hover:bg-brand-blue-hover text-white shadow-soft hover:shadow-glow-blue transition-all duration-200 flex items-center justify-center gap-2 group"
                    >
                      <span>Start a Conversation</span>
                      <Send className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </button>
                    <p className="text-[11px] text-slate-400 text-center mt-2.5">
                      Submitting initiates a pre-filled direct WhatsApp conversation with our engineering team.
                    </p>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
