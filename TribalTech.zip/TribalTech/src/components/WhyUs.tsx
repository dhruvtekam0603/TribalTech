import React from 'react';
import { WHY_US_FEATURES } from '../config/site';
import {
  UserCheck,
  Sparkles,
  Target,
  MessageSquare,
  CheckCircle,
  Users,
} from 'lucide-react';

export const WhyUs: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'UserCheck':
        return <UserCheck className="w-5 h-5 text-brand-blue" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-indigo-500" />;
      case 'Target':
        return <Target className="w-5 h-5 text-emerald-500" />;
      case 'MessageSquare':
        return <MessageSquare className="w-5 h-5 text-blue-500" />;
      default:
        return <CheckCircle className="w-5 h-5 text-brand-blue" />;
    }
  };

  return (
    <section id="about" className="py-20 md:py-28 bg-white border-y border-brand-border/60 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Heading & Philosophy */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-brand-slate text-xs font-bold tracking-widest uppercase">
              <span>WHY TRIBALTECH</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-brand-navy tracking-tight leading-tight">
              Technology should make business simpler.
            </h2>

            <p className="text-base sm:text-lg text-brand-slate leading-relaxed">
              We believe technology should solve real problems, not make things more complicated. We focus on understanding your business and building solutions that are useful, practical, and easy to work with.
            </p>

            {/* Studio Ethos Card */}
            <div className="p-6 rounded-2xl bg-brand-soft border border-slate-200/80 space-y-3 shadow-soft-sm">
              <div className="flex items-center gap-2 text-xs font-bold text-brand-navy">
                <Users className="w-4 h-4 text-brand-blue" />
                <span>The 3-Member Core Advantage</span>
              </div>
              <p className="text-xs text-brand-slate leading-relaxed">
                We are a small, ambitious team of 3 building digital solutions for businesses. We combine modern web technologies and AI-assisted engineering to craft bespoke experiences quickly and cost-effectively, without layers of agency bureaucracy.
              </p>
              <div className="pt-2 flex items-center gap-4 text-xs font-semibold text-brand-navy">
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Direct Access
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-brand-blue" /> Modern Tech
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" /> Fast Delivery
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: 4 Editorial Features */}
          <div className="lg:col-span-7 space-y-8">
            <div className="divide-y divide-slate-100">
              {WHY_US_FEATURES.map((feature) => (
                <div
                  key={feature.title}
                  className={`py-8 first:pt-0 last:pb-0 space-y-3 group transition-colors`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3.5">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200/80 flex items-center justify-center group-hover:bg-blue-50 group-hover:border-blue-200 transition-colors flex-shrink-0">
                        {getIcon(feature.icon)}
                      </div>
                      <h3 className="text-xl sm:text-2xl font-bold text-brand-navy group-hover:text-brand-blue transition-colors">
                        {feature.title}
                      </h3>
                    </div>

                    {feature.metric && (
                      <div className="text-right flex-shrink-0">
                        <span className="text-sm sm:text-base font-extrabold text-brand-navy font-mono">
                          {feature.metric}
                        </span>
                        <div className="text-[10px] text-slate-400 font-medium">
                          {feature.metricLabel}
                        </div>
                      </div>
                    )}
                  </div>

                  <p className="text-sm sm:text-base text-brand-slate leading-relaxed pl-0 sm:pl-[54px]">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
