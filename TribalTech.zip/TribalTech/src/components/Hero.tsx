import React, { useState } from 'react';
import { SITE_CONFIG } from '../config/site';
import {
  ArrowRight,
  Sparkles,
  Smartphone,
  Zap,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';

export const Hero: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'preview' | 'code'>('preview');

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const navHeight = 72;
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navHeight;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden bg-gradient-to-b from-white via-brand-soft to-slate-50"
    >
      {/* Background subtle geometric elements */}
      <div className="absolute inset-0 bg-grid-pattern opacity-60 pointer-events-none" />
      <div className="absolute top-20 right-1/4 w-96 h-96 bg-brand-blue/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 left-10 w-80 h-80 bg-slate-200/40 rounded-full blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline & Value Prop */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-center lg:text-left">
            
            {/* Eyebrow badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200/80 text-brand-blue text-xs sm:text-sm font-semibold tracking-wide">
              <span className="flex h-2 w-2 rounded-full bg-brand-blue animate-pulse" />
              <span>DIGITAL SOLUTIONS FOR AMBITIOUS BUSINESSES</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-brand-navy tracking-tight leading-[1.12]">
              Your business deserves{' '}
              <span className="relative inline-block text-brand-navy">
                <span className="relative z-10 text-brand-blue font-black">
                  more than just a presence.
                </span>
                <span
                  className="absolute bottom-1 sm:bottom-2 left-0 w-full h-3 sm:h-4 bg-brand-blue/10 -rotate-1 rounded -z-0"
                  aria-hidden="true"
                />
              </span>
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg lg:text-xl text-brand-slate max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
              {SITE_CONFIG.heroDescription}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('contact');
                }}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-full text-base font-semibold bg-brand-blue text-white hover:bg-brand-blue-hover shadow-soft hover:shadow-glow-blue transition-all duration-200 group"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
              </a>

              <a
                href="#work"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('work');
                }}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full text-base font-semibold bg-white text-brand-navy hover:bg-slate-50 border border-brand-border shadow-soft-sm transition-all duration-200"
              >
                <span>Explore Our Work</span>
              </a>
            </div>

            {/* Supporting Trust & Micro-proof */}
            <div className="pt-4 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 sm:gap-6 text-xs sm:text-sm text-brand-slate">
              <span className="font-medium text-brand-navy flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                {SITE_CONFIG.supportingTrust}
              </span>
              <div className="flex items-center gap-4 text-xs">
                <span className="flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-amber-500" /> &lt;1.5s Speed
                </span>
                <span className="flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5 text-blue-500" /> 100% Mobile First
                </span>
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" /> AI-Assisted Precision
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Creative Digital Studio Showcase */}
          <div className="lg:col-span-5 relative mt-4 lg:mt-0">
            {/* Ambient Backing Glow */}
            <div className="absolute -inset-4 bg-gradient-to-tr from-brand-blue/15 to-indigo-500/10 rounded-3xl blur-2xl -z-10" />

            {/* Main Browser Mockup Frame */}
            <div className="bg-white rounded-2xl shadow-soft-xl border border-brand-border overflow-hidden">
              {/* Browser Header Bar */}
              <div className="bg-slate-100/90 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                </div>
                
                {/* Fake URL bar */}
                <div className="px-3 py-0.5 rounded-md bg-white border border-slate-200/80 text-[11px] font-mono text-slate-500 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                  <span>https://client.tribaltech.dev</span>
                </div>

                {/* Mode toggle */}
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => setActiveTab('preview')}
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                      activeTab === 'preview'
                        ? 'bg-brand-navy text-white'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    UI
                  </button>
                  <button
                    onClick={() => setActiveTab('code')}
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                      activeTab === 'code'
                        ? 'bg-brand-navy text-white'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    Code
                  </button>
                </div>
              </div>

              {/* Browser Content Area */}
              {activeTab === 'preview' ? (
                <div className="p-4 sm:p-5 bg-gradient-to-br from-white to-slate-50 space-y-4">
                  {/* Mini preview hero */}
                  <div className="p-3.5 rounded-xl bg-brand-navy text-white space-y-2 relative overflow-hidden">
                    <div className="absolute right-0 top-0 w-24 h-24 bg-brand-blue/30 rounded-full blur-xl" />
                    <div className="flex items-center justify-between text-[11px] text-slate-300">
                      <span className="font-bold tracking-wider text-brand-blue">ACTIVE PLATFORM</span>
                      <span className="inline-flex items-center gap-1 text-emerald-400 text-[10px] bg-emerald-950/50 px-2 py-0.5 rounded-full border border-emerald-800">
                        <span className="w-1 h-1 rounded-full bg-emerald-400 animate-ping" />
                        Online 99.9%
                      </span>
                    </div>
                    <div className="text-base sm:text-lg font-bold leading-tight">
                      Elevate Your Business With Custom Digital Tools
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      Custom websites designed for higher customer conversions and direct WhatsApp orders.
                    </p>
                    <div className="pt-1 flex items-center gap-2">
                      <span className="text-[10px] font-semibold bg-brand-blue text-white px-2.5 py-1 rounded-md">
                        Get Instant Quote
                      </span>
                      <span className="text-[10px] text-slate-400">Response &lt; 15 mins</span>
                    </div>
                  </div>

                  {/* Micro dashboard cards */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-soft-sm">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[11px] text-slate-500 font-medium">Monthly Inquiries</span>
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                      </div>
                      <div className="text-lg font-bold text-brand-navy">+184%</div>
                      <div className="text-[10px] text-emerald-600 font-medium">Direct WhatsApp leads</div>
                    </div>

                    <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-soft-sm">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[11px] text-slate-500 font-medium">Page Load Speed</span>
                        <Zap className="w-3.5 h-3.5 text-amber-500" />
                      </div>
                      <div className="text-lg font-bold text-brand-navy">0.82s</div>
                      <div className="text-[10px] text-brand-blue font-medium">Lighthouse 98/100</div>
                    </div>
                  </div>

                  {/* Tech stack badge strip */}
                  <div className="pt-1 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-200/80">
                    <span className="font-semibold text-slate-600">Core Architecture:</span>
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-[10px] font-mono text-slate-700">React</span>
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-[10px] font-mono text-slate-700">TypeScript</span>
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-[10px] font-mono text-slate-700">Tailwind</span>
                    </div>
                  </div>
                </div>
              ) : (
                /* Code preview view */
                <div className="p-4 bg-brand-navy-deep text-slate-300 font-mono text-[11px] leading-relaxed overflow-x-auto space-y-1">
                  <div className="text-slate-500">// TribalTech Architecture Blueprint</div>
                  <div>
                    <span className="text-purple-400">const</span>{' '}
                    <span className="text-blue-300">TribalTechStudio</span> = &#123;
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">focus:</span>{' '}
                    <span className="text-emerald-300">'High-Impact Digital Solutions'</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">team:</span>{' '}
                    <span className="text-amber-300">3</span>,{' '}
                    <span className="text-slate-500">// Compact agile core</span>
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">deliverables:</span> [
                  </div>
                  <div className="pl-8 text-emerald-300">
                    'Modern Web', 'E-commerce', 'Automation'
                  </div>
                  <div className="pl-4">],</div>
                  <div className="pl-4">
                    <span className="text-slate-400">primaryChannel:</span>{' '}
                    <span className="text-emerald-300">'WhatsApp Business'</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">output:</span>{' '}
                    <span className="text-blue-400">()</span> =&gt;{' '}
                    <span className="text-emerald-300">'Measurable Growth'</span>
                  </div>
                  <div>&#125;;</div>
                </div>
              )}
            </div>

            {/* Floating Micro Badge 1 - AI & Design Precision */}
            <div className="hidden sm:flex absolute -bottom-5 -left-6 bg-white p-3 rounded-xl shadow-soft-lg border border-slate-200 items-center gap-3 animate-float">
              <div className="w-9 h-9 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-brand-blue font-bold">
                TT
              </div>
              <div className="leading-tight">
                <div className="text-xs font-bold text-brand-navy">AI-Assisted Precision</div>
                <div className="text-[11px] text-slate-500">Fast delivery, zero bloat</div>
              </div>
            </div>

            {/* Floating Micro Badge 2 - Live Chat Integration */}
            <div className="hidden sm:flex absolute -top-5 -right-4 bg-white p-2.5 px-3.5 rounded-xl shadow-soft-lg border border-slate-200 items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
              </span>
              <span className="text-xs font-semibold text-brand-navy">Direct WhatsApp Channel</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
