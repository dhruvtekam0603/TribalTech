import React from 'react';

interface BrandLogoProps {
  className?: string;
  variant?: 'full' | 'icon';
  theme?: 'light' | 'dark';
  showHindiBadge?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = 'h-9',
  variant = 'full',
  theme = 'light',
  showHindiBadge = true,
}) => {
  const isDark = theme === 'dark';
  const navyColor = isDark ? '#FFFFFF' : '#0B1220';
  const cutColor = isDark ? '#0B1220' : '#FFFFFF';
  const textColor = isDark ? '#FFFFFF' : '#0B1220';
  const dividerColor = isDark ? '#334155' : '#CBD5E1';

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* TT Geometric Monogram */}
      <svg
        viewBox="0 0 320 250"
        className="h-full w-auto flex-shrink-0"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <g transform="translate(10, 20)">
          {/* Left T navy wing */}
          <path d="M0 0 H140 V36 H94 V72 H68 V116 H36 V150 H0 V36 Z" fill={navyColor} />
          {/* Right T electric blue wing */}
          <path
            d="M160 0 H300 L264 36 H206 V72 H232 V116 H264 V150 H228 V116 H196 V72 H160 Z"
            fill="#2563EB"
          />
          {/* Negative space interior cuts */}
          <path d="M54 72 H94 V112 H68 V150 H54 Z" fill={cutColor} />
          <path d="M206 72 H246 L210 108 V150 H174 V108 H206 Z" fill={cutColor} />
          {/* Central spine anchor */}
          <path d="M94 36 H160 V150 H126 V186 H94 Z" fill={navyColor} />
          <path d="M126 36 H160 V150 H126 Z" fill="#2563EB" />
        </g>
      </svg>

      {variant === 'full' && (
        <div className="flex items-center gap-2">
          {/* Vertical divider */}
          <span
            className="w-[1.5px] h-6 rounded-full self-center"
            style={{ backgroundColor: dividerColor }}
          />

          <div className="flex flex-col justify-center leading-none">
            <div className="flex items-center gap-1.5">
              <span
                className="font-extrabold tracking-[0.14em] text-[1.125rem]"
                style={{ color: textColor }}
              >
                TRIBAL<span className="text-brand-blue">TECH</span>
              </span>
              {showHindiBadge && (
                <span
                  className={`text-[9px] font-semibold tracking-wider px-1.5 py-0.5 rounded ${
                    isDark
                      ? 'bg-brand-navy-surface text-slate-300 border border-slate-700/60'
                      : 'bg-slate-100 text-slate-600 border border-slate-200'
                  }`}
                  title="Hindi identity: Tribalटेक"
                >
                  टेक
                </span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
