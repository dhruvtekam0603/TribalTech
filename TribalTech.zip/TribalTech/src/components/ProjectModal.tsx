import React, { useEffect } from 'react';
import { ProjectConcept } from '../types';
import { getProjectInquiryUrl } from '../utils/whatsapp';
import {
  X,
  CheckCircle2,
  Layers,
  Sparkles,
  MessageCircle,
} from 'lucide-react';

interface ProjectModalProps {
  project: ProjectConcept | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-brand-navy-deep/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <span
              className="px-2.5 py-0.5 rounded-full text-xs font-bold"
              style={{
                backgroundColor: project.color.badgeBg,
                color: project.color.badgeText,
              }}
            >
              CONCEPT SHOWCASE
            </span>
            <span className="text-xs text-slate-500 font-medium hidden sm:inline">
              {project.category}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors"
            aria-label="Close concept preview"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-8">
          
          {/* Top Title & Overview */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-brand-blue uppercase tracking-wider">
              {project.industry}
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-brand-navy">
              {project.title}
            </h3>
            <p className="text-base text-brand-slate leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Interactive Simulation Frame */}
          <div className="rounded-xl border border-slate-200 overflow-hidden shadow-soft-md bg-white">
            {/* Simulated Browser Bar */}
            <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              </div>
              <div className="font-mono text-[11px] text-slate-500 bg-white px-3 py-0.5 rounded border border-slate-200">
                demo.{project.id}.tribaltech.dev
              </div>
              <span className="text-[10px] text-slate-400">Concept Demo</span>
            </div>

            {/* Custom Visual Identity Preview for this specific concept */}
            <div
              className="p-6 sm:p-8"
              style={{
                backgroundColor:
                  project.id === 'restaurant-cafe'
                    ? '#FFFDF9'
                    : project.id === 'retail-fashion'
                    ? '#F8FAFC'
                    : '#F0FDFA',
              }}
            >
              {/* Concept Mini Hero */}
              <div className="max-w-2xl mx-auto text-center space-y-3 mb-8">
                <span
                  className="text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full"
                  style={{
                    backgroundColor: project.color.badgeBg,
                    color: project.color.badgeText,
                  }}
                >
                  {project.mockup.headerTitle}
                </span>
                <h4
                  className="text-2xl sm:text-3xl font-bold tracking-tight"
                  style={{ color: project.color.primary }}
                >
                  {project.mockup.heroHeadline}
                </h4>
                <p className="text-sm text-slate-600">
                  {project.mockup.heroSubtitle}
                </p>
                <div className="pt-2">
                  <a
                    href={getProjectInquiryUrl(project.title)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold text-white shadow-soft transition-transform hover:scale-105"
                    style={{ backgroundColor: project.color.accent }}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{project.mockup.ctaText}</span>
                  </a>
                </div>
              </div>

              {/* Concept Mini Item Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {project.mockup.cardItems.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-white border border-slate-200/90 shadow-soft-sm space-y-2"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      {item.tag && (
                        <span
                          className="px-2 py-0.5 rounded font-semibold text-[10px]"
                          style={{
                            backgroundColor: project.color.badgeBg,
                            color: project.color.badgeText,
                          }}
                        >
                          {item.tag}
                        </span>
                      )}
                      {item.price && (
                        <span className="font-bold text-slate-900">{item.price}</span>
                      )}
                    </div>
                    <div className="font-bold text-slate-900 text-sm">{item.title}</div>
                    <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Key Design Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            <div className="space-y-3">
              <h5 className="text-sm font-bold text-brand-navy flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-brand-blue" />
                <span>Concept Highlights</span>
              </h5>
              <ul className="space-y-2">
                {project.highlights.map((h, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-brand-slate">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-3">
              <h5 className="text-sm font-bold text-brand-navy flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-500" />
                <span>Engineered For Conversion</span>
              </h5>
              <ul className="space-y-2">
                {project.features.map((f, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-brand-slate">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 mt-0.5 flex-shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Tech stack tags */}
          <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-medium">Stack:</span>
              {project.techStack.map((tech, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded bg-slate-100 font-mono text-[11px] text-slate-700 font-medium"
                >
                  {tech}
                </span>
              ))}
            </div>

            <div className="text-[11px] text-slate-400 italic">
              *TribalTech concept prototype
            </div>
          </div>

        </div>

        {/* Modal Bottom CTA */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0">
          <div className="text-xs text-slate-500 text-center sm:text-left">
            Ready to bring your business vision to life?
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-full text-xs font-semibold border border-slate-300 text-slate-700 hover:bg-slate-100 transition-colors"
            >
              Close
            </button>
            <a
              href={getProjectInquiryUrl(project.title)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full text-xs font-semibold bg-brand-navy text-white hover:bg-brand-blue transition-colors shadow-soft-sm"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>Discuss Similar Build</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
