import React from 'react';
import { PROCESS_STEPS } from '../config/site';
import { CheckCircle2 } from 'lucide-react';

export const Process: React.FC = () => {
  return (
    <section className="py-20 md:py-28 bg-brand-soft relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/70 text-brand-blue text-xs font-bold tracking-widest uppercase">
            <span>HOW WE WORK</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-brand-navy tracking-tight">
            From idea to launch. Without the complexity.
          </h2>

          <p className="text-base sm:text-lg text-brand-slate leading-relaxed">
            A transparent four-step engineering journey designed to keep you informed, aligned, and confident at every milestone.
          </p>
        </div>

        {/* 4 Steps Timeline Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 relative">
          
          {PROCESS_STEPS.map((step, index) => (
            <div
              key={step.step}
              className="relative bg-white rounded-2xl p-7 border border-brand-border shadow-soft-sm hover:shadow-soft-lg hover:border-brand-blue/40 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Step Number & Connector indicator */}
                <div className="flex items-center justify-between mb-6">
                  <span className="text-2xl font-black font-mono text-brand-navy group-hover:text-brand-blue transition-colors">
                    {step.step}
                  </span>
                  
                  <span className="w-8 h-8 rounded-full bg-blue-50 text-brand-blue flex items-center justify-center text-xs font-bold border border-blue-100 group-hover:bg-brand-blue group-hover:text-white transition-all">
                    0{index + 1}
                  </span>
                </div>

                {/* Step Title */}
                <h3 className="text-xl font-bold text-brand-navy mb-3 group-hover:text-brand-blue transition-colors">
                  {step.title}
                </h3>

                {/* Step Description */}
                <p className="text-sm text-brand-slate leading-relaxed mb-6">
                  {step.description}
                </p>
              </div>

              {/* Deliverables tags */}
              <div className="pt-4 border-t border-slate-100 space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Key Deliverables
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {step.deliverables.map((item, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}

        </div>

        {/* Bottom Process Guarantee note */}
        <div className="mt-12 text-center">
          <p className="text-xs sm:text-sm text-brand-slate inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-slate-200 shadow-soft-sm">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span>Regular preview links, zero jargon, and straightforward updates on WhatsApp throughout the sprint.</span>
          </p>
        </div>

      </div>
    </section>
  );
};
