import React, { useState } from 'react';
import { PROJECTS } from '../config/site';
import { ProjectConcept } from '../types';
import { ProjectModal } from './ProjectModal';
import { getProjectInquiryUrl } from '../utils/whatsapp';
import {
  ArrowUpRight,
  Sparkles,
  UtensilsCrossed,
  ShoppingBag,
  Building2,
  MessageCircle,
} from 'lucide-react';

export const Portfolio: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<ProjectConcept | null>(null);

  const getIndustryIcon = (industry: string) => {
    switch (industry) {
      case 'Hospitality':
        return <UtensilsCrossed className="w-4 h-4" />;
      case 'Retail & E-commerce':
        return <ShoppingBag className="w-4 h-4" />;
      case 'Real Estate':
        return <Building2 className="w-4 h-4" />;
      default:
        return <Sparkles className="w-4 h-4" />;
    }
  };

  return (
    <section id="work" className="py-20 md:py-28 bg-brand-soft relative overflow-hidden">
      {/* Background ambient accents */}
      <div className="absolute top-1/2 left-0 w-72 h-72 bg-brand-blue/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-80 h-80 bg-slate-200/50 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/70 text-brand-blue text-xs font-bold tracking-widest uppercase">
            <span>SELECTED PROJECTS</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-brand-navy tracking-tight">
            Ideas brought to life.
          </h2>

          <p className="text-base sm:text-lg text-brand-slate leading-relaxed">
            Explore digital experiences and concepts built with purpose, creativity, and attention to detail.
          </p>

          <div className="inline-block px-3.5 py-1 rounded-full bg-slate-200/70 text-slate-600 text-xs font-medium">
            Studio Concept Demonstrations · Tailored for Real-World Businesses
          </div>
        </div>

        {/* 3 Project Showcase Cards */}
        <div className="space-y-12 sm:space-y-16">
          {PROJECTS.map((project, index) => {
            const isReversed = index % 2 === 1;

            return (
              <div
                key={project.id}
                className="bg-white rounded-3xl border border-brand-border shadow-soft hover:shadow-soft-xl transition-all duration-300 overflow-hidden"
              >
                <div
                  className={`grid grid-cols-1 lg:grid-cols-12 items-center ${
                    isReversed ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  {/* Left Column: Project Details (or right if reversed) */}
                  <div
                    className={`p-8 sm:p-10 lg:p-12 lg:col-span-6 space-y-6 ${
                      isReversed ? 'lg:order-2' : 'lg:order-1'
                    }`}
                  >
                    {/* Category pill */}
                    <div className="flex items-center gap-2">
                      <span
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold"
                        style={{
                          backgroundColor: project.color.badgeBg,
                          color: project.color.badgeText,
                        }}
                      >
                        {getIndustryIcon(project.industry)}
                        <span>{project.category}</span>
                      </span>
                      <span className="text-xs font-semibold text-slate-400">
                        Concept 0{index + 1}
                      </span>
                    </div>

                    {/* Project Title & Tagline */}
                    <div>
                      <h3 className="text-2xl sm:text-3xl font-extrabold text-brand-navy mb-2">
                        {project.title}
                      </h3>
                      <p className="text-sm sm:text-base font-medium text-brand-blue">
                        {project.tagline}
                      </p>
                    </div>

                    {/* Description */}
                    <p className="text-sm text-brand-slate leading-relaxed">
                      {project.description}
                    </p>

                    {/* Key Highlights list */}
                    <div className="space-y-2 pt-1 border-t border-slate-100">
                      {project.highlights.slice(0, 3).map((item, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs text-brand-slate-dark">
                          <span className="w-1.5 h-1.5 rounded-full bg-brand-blue" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>

                    {/* Action buttons */}
                    <div className="pt-2 flex flex-wrap items-center gap-3">
                      <button
                        onClick={() => setSelectedProject(project)}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold bg-brand-navy text-white hover:bg-brand-blue transition-colors shadow-soft-sm group"
                      >
                        <span>View Concept</span>
                        <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </button>

                      <a
                        href={getProjectInquiryUrl(project.title)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-brand-slate hover:text-brand-navy hover:bg-slate-100 transition-colors"
                      >
                        <MessageCircle className="w-4 h-4 text-emerald-600" />
                        <span>Inquire About Similar Build</span>
                      </a>
                    </div>
                  </div>

                  {/* Right Column: Custom Visual Website Preview Mockup */}
                  <div
                    className={`p-6 sm:p-8 lg:p-10 lg:col-span-6 bg-slate-50/80 border-t lg:border-t-0 ${
                      isReversed
                        ? 'lg:border-r border-slate-100 lg:order-1'
                        : 'lg:border-l border-slate-100 lg:order-2'
                    }`}
                  >
                    {/* Simulated browser window with distinct styling per concept */}
                    <div className="bg-white rounded-2xl shadow-soft-lg border border-slate-200/90 overflow-hidden transform group-hover:scale-[1.01] transition-transform duration-300">
                      
                      {/* Browser header */}
                      <div className="bg-slate-100 px-3.5 py-2 border-b border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                        <div className="flex items-center space-x-1.5">
                          <span className="w-2 h-2 rounded-full bg-slate-300" />
                          <span className="w-2 h-2 rounded-full bg-slate-300" />
                          <span className="w-2 h-2 rounded-full bg-slate-300" />
                        </div>
                        <div className="font-mono text-[10px] bg-white px-2.5 py-0.5 rounded border border-slate-200 text-slate-600">
                          {project.id}.concept.preview
                        </div>
                        <span className="text-[10px] font-semibold text-brand-blue">DEMO</span>
                      </div>

                      {/* Mockup Body: Custom tailored aesthetic per concept */}
                      {project.id === 'restaurant-cafe' && (
                        <div className="p-5 bg-gradient-to-br from-amber-50/40 via-orange-50/20 to-white space-y-4">
                          <div className="flex items-center justify-between border-b border-orange-100 pb-2">
                            <span className="font-serif font-bold text-amber-950 text-sm tracking-wider">
                              THE COPPER KETTLE
                            </span>
                            <span className="text-[10px] text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded-full font-medium">
                              Open · Closes 11 PM
                            </span>
                          </div>

                          <div className="space-y-1.5 py-1">
                            <div className="text-xs font-serif font-bold text-amber-900">
                              Artisan Coffee & Sourdough Bakes
                            </div>
                            <p className="text-[11px] text-slate-600 leading-snug">
                              Specialty roasts, slow-fermented bakes, and bistro dining.
                            </p>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div className="p-2.5 rounded-lg bg-white border border-amber-200/60 shadow-soft-sm">
                              <span className="text-[9px] font-bold text-amber-700 uppercase tracking-wider">
                                Chef's Special
                              </span>
                              <div className="text-xs font-bold text-slate-900 mt-0.5">Truffle Sourdough</div>
                              <div className="text-[10px] text-slate-500">₹480 · Freshly baked</div>
                            </div>
                            <div className="p-2.5 rounded-lg bg-white border border-amber-200/60 shadow-soft-sm">
                              <span className="text-[9px] font-bold text-amber-700 uppercase tracking-wider">
                                Signature
                              </span>
                              <div className="text-xs font-bold text-slate-900 mt-0.5">Cold Brew Reserve</div>
                              <div className="text-[10px] text-slate-500">₹240 · 18hr extraction</div>
                            </div>
                          </div>

                          <div className="p-2 rounded-lg bg-amber-900 text-white flex items-center justify-between text-[11px] font-medium">
                            <span>Table Reservation via WhatsApp</span>
                            <span className="bg-amber-600 px-2 py-0.5 rounded text-[10px]">Instant</span>
                          </div>
                        </div>
                      )}

                      {project.id === 'retail-fashion' && (
                        <div className="p-5 bg-white space-y-4">
                          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                            <span className="font-extrabold tracking-widest text-slate-900 text-xs">
                              AURA / STUDIO
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">EDITION 04</span>
                          </div>

                          <div className="space-y-1.5 py-1">
                            <div className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                              Timeless Essentials
                            </div>
                            <p className="text-[11px] text-slate-500 leading-snug">
                              Curated minimalist apparel with frictionless shopping flow.
                            </p>
                          </div>

                          <div className="grid grid-cols-3 gap-2">
                            <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                              <div className="w-full h-12 bg-slate-200 rounded flex items-center justify-center text-[9px] text-slate-500 font-mono">
                                ITEM 01
                              </div>
                              <div className="text-[10px] font-bold text-slate-800 truncate">Merino Knit</div>
                              <div className="text-[9px] text-slate-500">₹3,400</div>
                            </div>
                            <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                              <div className="w-full h-12 bg-slate-200 rounded flex items-center justify-center text-[9px] text-slate-500 font-mono">
                                ITEM 02
                              </div>
                              <div className="text-[10px] font-bold text-slate-800 truncate">Canvas Tote</div>
                              <div className="text-[9px] text-slate-500">₹1,850</div>
                            </div>
                            <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                              <div className="w-full h-12 bg-slate-200 rounded flex items-center justify-center text-[9px] text-slate-500 font-mono">
                                ITEM 03
                              </div>
                              <div className="text-[10px] font-bold text-slate-800 truncate">Relaxed Pant</div>
                              <div className="text-[9px] text-slate-500">₹2,900</div>
                            </div>
                          </div>

                          <div className="p-2 rounded-lg bg-slate-900 text-white flex items-center justify-between text-[11px] font-medium">
                            <span>Cart & Fast Checkout</span>
                            <span className="bg-brand-blue px-2 py-0.5 rounded text-[10px]">Buy Direct</span>
                          </div>
                        </div>
                      )}

                      {project.id === 'real-estate' && (
                        <div className="p-5 bg-gradient-to-br from-teal-50/30 to-white space-y-4">
                          <div className="flex items-center justify-between border-b border-teal-100 pb-2">
                            <span className="font-bold text-teal-950 text-xs tracking-wider">
                              APEX HORIZON REALTY
                            </span>
                            <span className="text-[10px] text-teal-700 bg-teal-100 px-2 py-0.5 rounded-full font-medium">
                              Prime Listings
                            </span>
                          </div>

                          <div className="space-y-1.5 py-1">
                            <div className="text-xs font-bold text-teal-950">
                              Curated Luxury Residences
                            </div>
                            <p className="text-[11px] text-slate-600 leading-snug">
                              Filtered search, floor plans, and instant broker consultation.
                            </p>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div className="p-2.5 rounded-lg bg-white border border-teal-200/70 shadow-soft-sm">
                              <span className="text-[9px] font-bold text-teal-700 uppercase">
                                Meridian Penthouse
                              </span>
                              <div className="text-xs font-bold text-slate-900 mt-0.5">₹4.85 Cr</div>
                              <div className="text-[10px] text-slate-500">4 BHK · 4,200 sq.ft</div>
                            </div>
                            <div className="p-2.5 rounded-lg bg-white border border-teal-200/70 shadow-soft-sm">
                              <span className="text-[9px] font-bold text-teal-700 uppercase">
                                Verdant Groves Villa
                              </span>
                              <div className="text-xs font-bold text-slate-900 mt-0.5">₹6.20 Cr</div>
                              <div className="text-[10px] text-slate-500">5 BHK · Lake View</div>
                            </div>
                          </div>

                          <div className="p-2 rounded-lg bg-teal-900 text-white flex items-center justify-between text-[11px] font-medium">
                            <span>Schedule Private Site Visit</span>
                            <span className="bg-teal-600 px-2 py-0.5 rounded text-[10px]">VIP Tour</span>
                          </div>
                        </div>
                      )}

                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Concept Detail Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
