export interface NavItem {
  label: string;
  href: string;
}

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  description: string;
  tags: string[];
  features: string[];
  icon: string;
}

export interface ProjectConcept {
  id: string;
  title: string;
  category: string;
  tagline: string;
  description: string;
  industry: 'Hospitality' | 'Retail & E-commerce' | 'Real Estate';
  color: {
    primary: string;
    accent: string;
    badgeBg: string;
    badgeText: string;
  };
  highlights: string[];
  features: string[];
  techStack: string[];
  mockup: {
    headerTitle: string;
    heroHeadline: string;
    heroSubtitle: string;
    ctaText: string;
    cardItems: Array<{
      title: string;
      desc: string;
      tag?: string;
      price?: string;
    }>;
  };
}

export interface WhyUsFeature {
  title: string;
  description: string;
  metric?: string;
  metricLabel?: string;
  icon: string;
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  deliverables: string[];
}

export interface ContactFormData {
  name: string;
  businessName: string;
  contact: string;
  serviceNeeded: string;
  message: string;
}
