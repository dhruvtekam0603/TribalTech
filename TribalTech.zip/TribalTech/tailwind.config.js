/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          navy: '#0B1220',
          'navy-deep': '#060A12',
          'navy-surface': '#111A2E',
          'navy-card': '#152138',
          blue: '#2563EB',
          'blue-hover': '#1D4ED8',
          'blue-light': '#EFF6FF',
          'blue-muted': '#DBEAFE',
          soft: '#F8FAFC',
          slate: '#64748B',
          'slate-dark': '#334155',
          border: '#E2E8F0',
          'border-dark': '#1E293B',
        }
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
      },
      boxShadow: {
        'soft-sm': '0 1px 3px 0 rgba(11, 18, 32, 0.05), 0 1px 2px 0 rgba(11, 18, 32, 0.03)',
        'soft': '0 4px 16px -2px rgba(11, 18, 32, 0.06), 0 2px 6px -1px rgba(11, 18, 32, 0.03)',
        'soft-lg': '0 10px 25px -4px rgba(11, 18, 32, 0.08), 0 4px 10px -2px rgba(11, 18, 32, 0.04)',
        'soft-xl': '0 20px 35px -6px rgba(11, 18, 32, 0.1), 0 8px 16px -3px rgba(11, 18, 32, 0.05)',
        'glow-blue': '0 0 25px -5px rgba(37, 99, 235, 0.35)',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-6px)' },
        },
        pulseGlow: {
          '0%, 100%': { opacity: '0.4' },
          '50%': { opacity: '0.8' },
        }
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        'pulse-slow': 'pulseGlow 4s ease-in-out infinite',
      }
    },
  },
  plugins: [],
}
