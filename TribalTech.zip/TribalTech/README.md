# TribalTech (Tribalटेक) — Official Website

Modern, premium, responsive website for **TribalTech**, a technology business delivering custom web development, digital solutions, and business automation.

Built with **React 18**, **TypeScript**, **Vite**, and **Tailwind CSS**.

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Build for Production
```bash
npm run build
```
Production assets are generated in the `dist/` directory.

### 4. Preview Production Build
```bash
npm run preview
```

---

## 🎨 Brand Identity & Design System

- **Brand Name:** TribalTech
- **Hindi Identity:** Tribalटेक
- **Colors:**
  - **Midnight Navy:** `#0B1220` (Dark backgrounds, primary headings, high-contrast CTA & footer)
  - **Electric Blue:** `#2563EB` (Primary brand accent, interactive elements, highlights)
  - **Soft Background:** `#F8FAFC` (Page background for clean, airy feel)
  - **Slate Grey:** `#64748B` (Subtle body copy, meta labels)
  - **Border:** `#E2E8F0` (Crisp separation without visual noise)
- **Typography:** Plus Jakarta Sans & Inter
- **Aesthetic:** Editorial, modern, confident, technological, and clean.

---

## 📱 Configuration

All contact information and website content can be configured in a single file:

👉 [`src/config/site.ts`](src/config/site.ts)

### Setting the Official WhatsApp Number
Open `src/config/site.ts` and update:
```typescript
export const WHATSAPP_NUMBER = "91XXXXXXXXXX"; // Replace with your country code + phone number (e.g., 919876543210)
```

### Social Links & Email
Update `SITE_CONFIG` in `src/config/site.ts`:
- `email`: Official email address
- `instagram`: Instagram handle URL

---

## 📂 Project Structure

```
TribalTech/
├── public/                     # Static assets (favicons, SVGs)
│   ├── tribaltech_icon.svg
│   └── tribaltech_logo.svg
├── src/
│   ├── assets/                 # Brand assets
│   ├── components/             # Reusable UI components
│   │   ├── BrandLogo.tsx       # Vector TT monogram & wordmark
│   │   ├── Navbar.tsx          # Sticky responsive navigation with mobile drawer
│   │   ├── Hero.tsx            # High-impact hero with interactive studio showcase
│   │   ├── Services.tsx        # 6 core service offerings with quick inquiries
│   │   ├── Portfolio.tsx       # 3 concept project showcases with distinct visual identities
│   │   ├── ProjectModal.tsx    # Interactive demo preview modal
│   │   ├── WhyUs.tsx           # Editorial typography & 3-member studio ethos
│   │   ├── Process.tsx         # 4-step clear development timeline
│   │   ├── Contact.tsx         # Dark Navy CTA section with validated WhatsApp form
│   │   ├── Footer.tsx          # Complete footer with Hindi mark & dynamic year
│   │   └── FloatingWhatsApp.tsx# Sticky floating WhatsApp button with pulse indicator
│   ├── config/
│   │   └── site.ts             # Central configuration (WhatsApp, copy, data)
│   ├── types/
│   │   └── index.ts            # TypeScript definitions
│   ├── utils/
│   │   └── whatsapp.ts         # WhatsApp deep link generators & pre-fill helpers
│   ├── App.tsx                 # Root layout assembling all sections
│   ├── index.css               # Tailwind directives & custom utilities
│   └── main.tsx                # React entry point
├── index.html                  # HTML template with SEO & Open Graph meta tags
├── tailwind.config.js          # Tailwind theme & color tokens
├── tsconfig.json               # TypeScript configuration
└── vite.config.ts              # Vite configuration
```

---

## 🛠 Features & Capabilities

- **Frictionless WhatsApp Integration:** Centralized configuration with automated message pre-filling for general inquiries, specific services, concept inquiries, and contact form submissions.
- **Concept Showcase Modals:** Interactive browser simulation showing realistic design directions for restaurants, retail e-commerce, and real estate businesses.
- **Responsive Navigation:** Smooth section scrolling, active scroll spy, mobile slide-down drawer, and accessibility labels.
- **Form Validation:** Validates required fields, formats an organized summary, opens WhatsApp directly, and includes a fallback "Copy to Clipboard" button.
- **Optimized Performance:** Clean bundle size (68 KB JS gzipped, 7 KB CSS gzipped), semantic HTML5, and full reduced-motion accessibility support.
